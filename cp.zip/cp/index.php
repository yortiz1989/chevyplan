<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Form</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="assets/img/favicon.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
   </head>  
   <body>
   <div class="container">
    <br> 
      <div class="login-box-body">
        <h6 style="color:blue"></i> Aportes en linea rápidos y seguros 
        <img src="img/logopse.png" width="100" height="100"></h6>
        <p>Ahora puedes hacer tus aportes mensuales correspondientes a la cuota de tu Plan de ahorro Ingresando
        a nuestra plataforma de pagos en linea</p>
        <br/>
        <form method="POST" action="index.php">
            <div class="row">
                <div class="col">
                <label for="exampleFormControlSelect2">Tipo de documento</label>
                <select class="form-control" id="exampleFormControlSelect1" placeholder="Tipo de documento" required>
                    <option value="1">Cedula de ciudadanía</option>
                    <option value="2">Cedula de extranjería</option>
                    <option value="3">NIT</option>
                    <option value="4">Pasaporte</option>
                    </select>
                </div>
                <div class="col">
                <label for="exampleFormControlSelect2">Número de documento</label>
                <input minlength="5" maxlength="10" type="number" name ="documento" class="form-control" placeholder="Ingresar Numero de Documento" required>
                </div>
            </div><br>
            <button type="submit" class="btn btn-primary">Consultar</button>
        </form>



      <?php 
      error_reporting(0);
        $data= json_decode (file_get_contents("http://localhost/cp/consultapagos.json"), true);
        //print_r($data);        
        for($i=0;$i<count($data); $i++){
          echo $data[$i];
        }

        include 'conexion.php';
        $documento = 1;
        $documento = $_POST["documento"];
                        $resultado=mysqli_query($conexion," select * from producto where producto.id_cliente = '$documento' and producto.vigencia = 1");
                          while ($mostrar=mysqli_fetch_array($resultado)){
                           ?>
                        <tr>
                          <td><b>id_cliente: </b><?php echo $mostrar['id_cliente'] ?></td>                         
                          <td><b>Num de plan: </b><?php echo $mostrar['num_plan']?></td>
                          <td><b>Valor: </b><?php echo $mostrar['valor']?></td>
                          <td><b>Fecha de vencimiento:</b> <?php echo $mostrar['fec_venc']?></td>
                          <td><b>Vigencia:</b> <?php echo $mostrar['vigencia']?></td>
                          <br>
                    <?php } ?>
     </div>   
  </body>
</html>