-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-05-2021 a las 17:33:22
-- Versión del servidor: 10.4.19-MariaDB
-- Versión de PHP: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `chevyplan`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `Identificacion` int(30) NOT NULL,
  `Tipo` varchar(2) NOT NULL,
  `Nombre` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`Identificacion`, `Tipo`, `Nombre`) VALUES
(1012392334, '1', 'john rojas'),
(1022456789, '1', 'Camilo Perez'),
(1012456654, '1', 'Jose Mujica');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `identificacion`
--

CREATE TABLE `identificacion` (
  `id` int(3) NOT NULL,
  `descripcion` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `identificacion`
--

INSERT INTO `identificacion` (`id`, `descripcion`) VALUES
(1, 'Cedula de ciudadanía'),
(2, 'Cedula de extranjería'),
(3, 'NIT'),
(4, 'Pasaporte');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `id_cliente` int(15) NOT NULL,
  `num_plan` int(30) NOT NULL,
  `valor` int(10) NOT NULL,
  `fec_venc` date NOT NULL,
  `vigencia` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`id_cliente`, `num_plan`, `valor`, `fec_venc`, `vigencia`) VALUES
(0, 123456, 520000, '2021-03-15', 1),
(0, 654321, 420000, '2021-04-14', 0),
(0, 654123, 320000, '2021-05-24', 1),
(1012392334, 123456, 520000, '2021-03-15', 1),
(1012392334, 654321, 420000, '2021-04-14', 0),
(1012392334, 654123, 320000, '2021-05-24', 1),
(1022456789, 198765, 200000, '2021-03-17', 1),
(1022456789, 97865, 430000, '2021-04-20', 1),
(1022456789, 3454352, 315000, '2021-04-13', 0),
(1022456789, 99834334, 712000, '2021-05-24', 1),
(1012456654, 246908, 333000, '2021-05-24', 1),
(1012456654, 23132325, 4440000, '2021-05-02', 0),
(1012456654, 730176, 560000, '2021-02-10', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
